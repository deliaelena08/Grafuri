#include <fstream>
#include <vector>
#include <queue>
#include <bitset>
#include <cmath>
#include <iostream>
#define INF 1000
using namespace std;

ifstream fin("citire.in");

const int Max = 5e4 + 1;
const int Inf = 1 << 30;

int n, m; //n=nr de noduri, m=nr de muchii

float a[100][100];
float cost[100];
int visited[100];

int coordonates[101][101];
void read()
{
    int x, y;
    int xc,yc;
    float z;
    fin >> n >> m;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            a[i][j]=a[j][i]=INF;

    for(int i=1;i<=n;i++) //parcurgem coordonatele
    {
        fin>>xc>>yc;
        coordonates[i][1]=xc;
        coordonates[i][2]=yc;
    }


    for (int i = 1; i <= m; ++i)
    {
        fin >> x >> y ; //exista muchie intre x si y, trebuie sa calculam distanta
        z= sqrt((coordonates[x][1] - coordonates[y][1]) * (coordonates[x][1] - coordonates[y][1]) + (coordonates[x][2] - coordonates[y][2]) * (coordonates[x][2] - coordonates[y][2]));
        a[x][y]=z;
        a[y][x]=z;
    }
}

void Bellman_Ford(int nod) {
    int x;
    for (int i = 1; i <= n; i++)
        cost[i] = INF, visited[i] = 0;

    cost[nod] = 0;
    visited[nod] = 1;
    std::queue<int> c;

    c.push(nod);
    while (!c.empty()) {
        x = c.front();
        for (int i = 1; i <= n; i++)
            if (a[x][i] < INF && cost[i] > cost[x] + a[x][i]) {
                cost[i] = cost[x] + a[x][i];
                c.push(i);
                visited[i] = 1;
            }
        c.pop();
        visited[x] = 0;
    }


}

int main()
{
    read();
    int start,finish;
    cout<<"Introduceti numarul de inceput de la tastatura: ";
    cin>>start;
    cout<<"Introduceti nr de final de la tastratura: ";
    cin>>finish;
    Bellman_Ford(start);
    cout << cost[finish];

    return 0;
}