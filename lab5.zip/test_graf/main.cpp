#include <iostream>
#include<fstream>
#include <cmath>

using namespace std;
ifstream f("fisier.in");
ifstream f2("fisier2.in");
int ma[11][11],lm[100][2],cord[1001][2],s,parents[100];
float ma1[1001][1001];
float distance1[10001];
bool visited[1001];

void initializare(int s,int v)
{
    for (int i=0;i<v;i++)
    {
        distance1[i]=100001;
        parents[i]=-1;
    }
    distance1[s]=0;
}

void relax(int u,int v,int w)
{
    if(distance1[v] > distance1[u] + w)
    {
        distance1[v]= distance1[u] + w;
        parents[v]=u;
    }
}

int find_min_vertex(int v){
    int min_distance=100001;
    int min_index=-1;
    for(int i=0;i<v;i++){
        if(!visited[i] and distance1[i] < min_distance){
            min_distance=distance1[v];
            min_index=i;
        }
    }
    return min_index;
}


bool Bellman_ford(int s,int e,int v)
{
    initializare(s,v);
    for (int i=0;i<v-1;i++)
        for(int j=0;j<e;j++)
            for(int k=0;k<e;k++)
                if(ma1[j][k]!=0)
                    relax(j,k,ma1[j][k]);

    for(int u=0;u<e;u++)
    {
        for(int v=0;v<e;v++)
        {
            if(ma1[u][v]!=0)
            {
                if(distance1[v] > distance1[u] + ma1[u][v])
                    return false;
            }
        }
    }
    return true;
}

int main() {
    /** int nr = 1, n;
     f >> n;
     for (int i = 1; i <= n; i++) {
         for (int j = 1; j <= n; j++) {
             f >> ma[i][j];
             if (ma[i][j] == 1 && (lm[i][2] == 0 or lm[j][1] == 0)) {
                 lm[nr][1] = i;
                 lm[nr][2] = j;
                 nr++;
             }
         }
     }
     for (int i = 1; i < nr; i++) {
         cout << lm[i][1] << ' ' << lm[i][2] << '\n';
     }**/
    int n, m, v1, v2;
    f2 >> n >> m;
    for(int i=0;i<=n;i++)
        for(int j=0;j<=n;j++)
            ma1[i][j]=ma1[j][i]=100001;
    int nr = 0;
    for (int i = 0; i < n; i++) {
        f2 >> v1 >> v2;
        cord[nr][1] = v1;
        cord[nr][2] = v2;
        nr++;
    }

    int x,y;
    for (int j = 0; j < m; j++) {
        f2 >> x>>y;
        float r = sqrt(sqrt((cord[x][1]-cord[y][1])*(cord[x][1]-cord[y][1])+(cord[x][2]-cord[y][2])*(cord[x][2]-cord[y][2])));
        ma1[x-1][y-1] = r;
        ma1[y-1][x-1] = r;

    }
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << ma1[i][j] << ' ';
        }
        cout << '\n';
    }

    int s,f;
    cout<<"Introduceti  orasul sursa:";
    cin>>s;
    cout<<"Introduceti  orasul final:";
    cin>>f;
    initializare(s,n);
    bool val= Bellman_ford(s,m,n);
    if(val==true)
        cout << distance1[f];
    return 0;
}