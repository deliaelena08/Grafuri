#include <fstream>
#include<iostream>
#include <limits>
#include <queue>
using namespace std;

int ma[100][100],v,e,s,x,y,w,distance1[100],parents[100];
bool visited[1001];
/**void initializare(int s,int v)
{
    for (int i=0;i<v;i++)
    {
        distance1[i]=100001;
        parents[i]=-1;
    }
    distance1[s]=0;
}

void relax(int u,int v,int w)
{
    if(distance1[v]>distance1[u]+w)
    {
        distance1[v]=distance1[u]+w;
        parents[v]=u;
    }
}

int find_min_vertex(int v){
    int min_distance=100001;
    int min_index=-1;
    for(int i=0;i<v;i++){
        if(!visited[i] and distance1[i]<min_distance){
            min_distance=distance1[v];
            min_index=i;
        }
    }
    return min_index;
}


bool Bellman_ford(int s,int e,int v)
{
    initializare(s,v);
    for (int i=0;i<v-1;i++)
        for(int j=0;j<e;j++)
            for(int k=0;k<e;k++)
                if(ma[j][k]!=0)
                    relax(j,k,ma[j][k]);

    for(int u=0;u<e;u++)
    {
        for(int v=0;v<e;v++)
        {
            if(ma[u][v]!=0)
            {
                if(distance1[v]>distance1[u]+ma[u][v])
                    return false;
            }
        }
    }
    return true;
}

 **/
void Bellman_Ford(int nod) {
    int x;
    for (int i = 0; i < v; i++)
        distance1[i] = 100001, visited[i] = false;

    distance1[nod] = 0;
    visited[nod] = true;
    std::queue<int> c;

    c.push(nod);
    while (!c.empty()) {
        x = c.front();
        for (int i = 0; i < v-1; i++)
            if (ma[x][i] != 0 && distance1[i] > distance1[x] + ma[x][i]) {
                distance1[i] = distance1[x] + ma[x][i];
                c.push(i);
                visited[i] = 1;
            }
        c.pop();
        visited[x] = 0;
    }
}


void initialize(int nod){
    for(int i=0;i<v;i++)
        for(int j=0;j<v;j++)
            if(i!=j && ma[i][j]==0)
                ma[i][j]=100001;
    for(int i=0;i<v;i++)
    {
        distance1[i]=ma[nod][i];
        if(ma[nod][i]!=100001)
            parents[i]=nod;
        else
            parents[i]=-1;
        visited[i]=false;
    }
}

void dijkstra(int nod){
    initialize(nod);
    visited[nod]=true;
    bool ok=true;
    int mini,k;
    while(ok){
        mini=100001;
        for(int i=0;i<v;i++)
            if(!visited[i] && mini > distance1[i])
                mini=distance1[i], k=i;
        if(mini!=100001)
        {
            visited[k]=1;
            for(int i=0;i<v;i++)
                if(!visited[i] && distance1[i] > distance1[k] + ma[k][i])
                {
                    distance1[i]= distance1[k] + ma[k][i];
                    parents[i]=k;
                }
        }
        else
            ok=false;
    }
}



void Johnson(){
    for(int i=0;i<v;i++)
        ma[v+1][i]=0;
    Bellman_Ford(v+1);
        for (int i = 0; i < v; i++) {
            for (int j = 0; j < v; j++)
                if (ma[i][j] != 0 && ma[i][j] != 100001)
                {
                    ma[i][j] = ma[i][j] + distance1[i] - distance1[j];
                }
        }
}

int main(int argc,char *argv[]) {
    std::ifstream fin(argv[1]);
    std::ofstream fout(argv[2]);

    fin>>v>>e;
    for(int i=0;i<e;i++)
    {
        fin>>x>>y>>w;
        ma[x][y]=w;
    }
    Johnson();
    for(int i=0;i<v;i++)
        for(int j=0;j<v;j++)
            if(ma[i][j]!=0&& ma[i][j]!=100001)
                fout<<i<<' '<<j<<' '<<ma[i][j]<<'\n';

    for(int j=0;j<v;j++){
        dijkstra(j);
        for(int jj=0;jj<v;jj++) {
            if (distance1[jj] > 99990)
                fout << "INF" << ' ';
            else
                fout<<distance1[jj]<<' ';
        }
        fout<<'\n';
    }
    fin.close();
    fout.close();

    /**bool val= Bellman_ford(s,e,v);
    if (val==true)
    {
        for (int i = 0; i < v; i++) {
            if (distance1[i] ==100001 )
                fout << "INF" << ' ';
            else
                fout << distance1[i] << ' ';
        }
    }**/


}
