#include <iostream>

#include <fstream>
#include <cstring>
using namespace std;
ifstream in("graf3.txt");
ifstream gf("graf.txt");
ifstream l1("labirint_1.txt");
ifstream l2("labirint_2.txt");
ifstream l3("labirint_cuvinte.txt");
ifstream l4("labirint.txt");
ifstream p4("graf4.txt");
ifstream p5("graf5.txt");
ofstream g("labirint.txt");
ofstream g2("labirint2.txt");
int parents[100],viz[100],queue[100],list[100];
int ma32[1000][1000],ma3[1000][1000],ma1[100][100],ma0[100][100],ma[100][100],ma5[100][100],tr[100][100];
int n1,m1,n0,m0,n,m,vs,pozi,pozi2,pozj2,pozj,nrl,nrc,nrl2,nrc2,x;

void citire2(int ma[100][100])
{
    int x1,x2;
    in>>n>>m;
    for (int i=1;i<=m;i++)
    {
        in>>x1>>x2;
        ma[x1][x2]=1;
    }
}

void afis2(int tr[100][100])
{
    for(int i=0;i<n;i++)
    {
        for (int j=0;j<n;j++)
            cout<<tr[i][j]<<' ';
        cout<<'\n';
    }
}

void creare2(int tr[100][100],int ma[100][100])
{
    for(int i=0;i<n;i++)
        for(int j=0;j<n;j++)
            if(ma[i][j]==1 or i==j)
                tr[i][j]=1;
}

void roy_f(int tr[100][100])
    {
        int i,j,k;
        for(i=0;i<n;i++)
            for(j=0;j<n;j++)
                for(k=0;k<n;k++)
                    if(tr[i][j]==0 && tr[i][k]==1 && tr[k][j]==1)
                            tr[i][j]=1;
    }

void citire1(int ma0[100][100],int &vs,int &n0,int &m0)
{
    int x1,x2;
    gf>>vs;
    gf>>n0>>m0;
    for (int i=1;i<=m0;i++)
    {
        gf>>x1>>x2;
        ma0[x1][x2]=1;
    }
}

int* bfs(int start)
{
    int i,k,st,dr;
    int* d = new int[n+1];
    for(int i=1; i<=n; i++) {
        d[i] = -1;
    }
    st=dr=1;
    queue[1]=start;
    d[start] = 0;
    while(st<=dr)
    {
        k=queue[st];
        for(i=1;i<=n1;i++)
            if(ma1[k][i]==1 && d[i] == -1)
            {
                d[i] = d[k] +1;
                queue[++dr]=i;
            }
        st++;
    }
    return d;
}

void citire4()
{
    int x1,x2;
    p4>>n1>>m1;
    for (int i=1;i<=m1;i++)
    {
        p4>>x1>>x2;
        ma1[x1][x2]=1;
    }
}

void citire5(int &x)
{
    int x1,x2;
    p5>>x;
    p5>>n1>>m1;
    for (int i=1;i<=m1;i++)
    {
        p5>>x1>>x2;
        ma5[x1][x2]=1;
    }
}

void dfs(int x)
{
    cout<<x<<' ';
    viz[x]=1;
    for(int i=1;i<=n;i++)
        if(ma5[x][i]==1 && viz[i]==0) dfs(i);
}

void afis4()
{
    int* nr=bfs(1);
    for(int i=1;i<=n1;i++)
        if(nr[i]>0)
            cout<<"nodul "<<i<<" are distanta fata de radacina de "<<nr[i]<<"\n";
}

void moore(int &vs,int parents[100],int queue[100],int list[100])
{
    for(int i=1;i<=n0;i++)
         list[i]=1001;
    list[vs]=0;
    int size=1;
    queue[0]=vs;
    for(int p=0;p<size;p++)
    {
        int varf=queue[p];
        for (int i=1;i<=n0 ;i++)
            if (list[i]==1001 && ma0[varf][i]==1) {
                parents[i] = varf;
                list[i] = list[varf] + 1;
                queue[size++] = i;
            }
    }
}

void afis1(int &vs,int parents[100])
{
   int x;
   for(int i=1;i<=n0;i++)
   {
       x=i;
       while(parents[x])
       {
           cout<<x<<' ';
           x=parents[x];
       }
       if(x==vs)
           cout<<x<<'\n';
   }
}

void citire_labirint(int ma3[1000][1000],int &pozi,int &pozj,int &nrl,int &nrc)
{
    if (!l1.is_open()) {
        cerr << "Error opening file\n";
        return;
    }
    string line;
    char a='1';
    char b=' ';
    char c='S';
    char d='F';
    while(getline(l1, line))
    {
        for(int i=0;i<line.length();i++)
        {
            if(line[i]==a)
                ma3[nrl][i]=-1;
            if(line[i]==b)
                ma3[nrl][i]=0;
            if(line[i]==c)
            {
                pozi=nrl;
                pozj=i;
            }
            if(line[i]==d)
                ma3[nrl][i]=1;
        }
        if(nrc==0)
            nrc=line.length();
        nrl++;
        line[0]='\0';
    }
    l1.close();
}

bool bfs(int x,int y,int ma3[1000][1000], int nrl, int nrc)
{
    if( ma3[x][y]==-1 or ma3[x][y]==-2 or ma3[x][y]==2 or x<0 or y<0 or x>=nrl or y>=nrc)
        return false;
    if (ma3[x][y]==1 )
        return true;
    ma3[x][y]=-2;
    bool ok= (bfs(x+1,y,ma3,nrl,nrc) or bfs(x,y+1,ma3,nrl,nrc)) or (bfs(x-1,y,ma3,nrl,nrc) or bfs(x,y-1,ma3,nrl,nrc));
    if(ok== false)
        ma3[x][y]=2;
    return ok;
}

void afis3(int ma3[1000][1000],int &pozi,int &pozj)
{
    for(int i=0;i<nrl;i++)
    {
        for (int j=0;j<nrc;j++) {
            if (ma3[i][j] == 2 or ma3[i][j]==0)
                g <<' ';
            else {
                if (ma3[i][j] == -2)
                {
                    g << "*";
                    cout<<i<<' '<<j<<'\n';
                }
                else
                {
                    if (i == pozi && j == pozj)
                        g << "S";
                    else
                    {
                        if(ma3[i][j]==1)
                            g<<"F";
                        else
                            g << "1";
                    }
                }
            }
        }
        g<<'\n';
    }
}

void citire_labirint_concurs(int ma4[1000][1000]){

}

void citire_labirint2(int ma32[1000][1000],int &pozi2,int &pozj2,int &nrl2,int &nrc2)
{
    if (!l2.is_open()) {
        cerr << "Error opening file\n";
        return;
    }
    string line2;
    char a='1';
    char b=' ';
    char c='S';
    char d='F';
    while(getline(l2, line2))
    {
        for(int i=0;i<line2.length();i++)
        {
            if(line2[i]==a)
                ma32[nrl2][i]=-1;
            if(line2[i]==b)
                ma32[nrl2][i]=0;
            if(line2[i]==c)
            {
                pozi2=nrl2;
                pozj2=i;
            }
            if(line2[i]==d)
                ma32[nrl2][i]=1;
        }
        if(nrc2==0)
            nrc2=line2.length();
        nrl2++;
        line2[0]='\0';
    }
    l2.close();
}

void afis32(int ma32[1000][1000],int &pozi2,int &pozj2)
{
    for(int i=0;i<nrl2;i++)
    {
        for (int j=0;j<nrc2;j++) {
            if (ma32[i][j] == 2 or ma32[i][j]==0)
                g2 <<' ';
            else {
                if (ma32[i][j] == -2)
                {
                    g2 << "*";
                    cout<<i<<" "<<j<<'\n';
                }
                else
                {
                    if (i == pozi2 && j == pozj2)
                        g2 << "S";
                    else
                    {
                        if(ma32[i][j]==1)
                            g2<<"F";
                        else
                            g2 << "1";
                    }
                }
            }
        }
        g2<<'\n';
    }
}

int main()
{

    cout<<"Problema numarul 1: \n";
    citire1(ma0,vs,n0,m0);
    moore(vs,parents,queue,list);
    afis1(vs,parents);
    cout<<'\n';

    cout<<"Problema numarul 2: \n";
    citire2(ma);
    creare2(tr,ma);
    roy_f(tr);
    afis2(ma);
    cout<<'\n';
    afis2(tr);
    cout<<'\n';

    cout<<"Labirint 1 se afla in labirint.txt\n";
    citire_labirint(ma3,pozi,pozj,nrl,nrc);
    bfs(pozi,pozj,ma3,nrl,nrc);
    afis3(ma3,pozi,pozj);
    cout<<"Labirint 2 se afla in labirint2.txt\n";
    citire_labirint2(ma32,pozi2,pozj2,nrl2,nrc2);
    bfs(pozi2,pozj2,ma32,nrl2,nrc2);
    afis32(ma32,pozi2,pozj2);

    cout<<"Problema numarul 4: \n";
    citire4();
    afis4();
    cout<<'\n';

    cout<<"Problema numarul 5: \n";
    citire5(x);
    dfs(x);

    return 0;
}
