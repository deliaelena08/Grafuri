#include<iostream>
#include<fstream>
using namespace std;
ifstream in("graf2.txt");
int ma[100][100],n,grad[100],viz[101],md[100][100],maxx=1000000;

void citire()
{
    in>>n;
    for (int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            in>>ma[i][j];
}

void creare(int ma[100][100],int n,int md[100][100])
{
    int i,j,x;
    for(i=1;i<=n;i++)
        for(j=i+1;j<=n;j++)
            md[i][j]=md[j][i]=maxx;

    for (int i=1;i<=n;i++)
        for (int j=1;j<=n;j++)
            if (ma[i][j]==1)
                md[i][j]=md[j][i]=1;
}

void roy_f(int md[100][100])
{
    int i,j,k;
    for(k=1;k<=n;k++)
        for(i=1;i<=n;i++)
            for(j=1;j<=n;j++)
                if(i!=j)
                    if(md[i][j]>md[i][k]+md[k][j])
                        md[i][j]=md[i][k]+md[k][j];
}

void afis(int md[100][100])
{
    int i,j;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
            if(md[i][j]!=maxx) cout<<md[i][j]<<" ";
            else cout<<0<<' ';
        cout<<"\n";
    }
}

void dfs(int x)
{
    viz[x]=1;
    for(int i=1;i<=n;i++)
        if(ma[x][i]==1 && viz[i]==0) dfs(i);
}

void graduri(int grad[100])
{
    for (int i=1;i<=n;i++)
    {
        grad[i]=0;
        for (int j = 1; j <= n; j++)
            if(ma[i][j]==1)
                grad[i]++;
    }
}
int main()
{
    citire();
    int nr=0;

    for (int i=1;i<=n;i++)
    {
        int ok=0;
        for (int j = 1; j <= n; j++)
            if(ma[i][j]==1)
                ok=1;
        if (ok==0)
            nr++;
    }
    cout<<"Numarul de noduri izolate este "<<nr<<"\n";
    cout<<"\n";

    graduri(grad);
    int ok=0;
    for (int i=2;i<=n;i++)
        if(grad[i-1]!=grad[i])
            ok=1;
    if(ok==0)
        cout<<"Graful este regulat"<<"\n";
    else
        cout<<"Graful nu este regulat"<<"\n";
    cout<<"\n";

    creare(ma,n,md);
    roy_f(md);
    afis(md);
    cout<<"\n";

    dfs(1);
    int k=1;
    for(int i=1;i<=n && ok;i++)
        if(viz[i]==0)k=0;
    if(k==1)cout<<"Graful este conex";
    else cout<<"Graful nu este conex";
    cout<<"\n";
}